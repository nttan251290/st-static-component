
function accordionHistory() {
  var btnAccordion = $('[data-toggle="accordion"]');

  btnAccordion.on('click.accordionHistory', function() {
    $(this).find('.icon_image').toggleClass('expand');
    $(this).closest('.acccordion_item').find('.accordion_panel').toggleClass('active');
  });

}

accordionHistory();